**Design Document: Eleanor's Boutique**

**Table of Contents**
1. Project Architecture
2. Database Design
4. Frontend Design
5. Backend Design
6. Technical Challenges
7. Future Improvements

1.
**Project architecture:**
This is the architecture of my project:

SHOPPING/
│
├── static/               # Static assets (CSS, JavaScript, images)
│   ├── images/           # Product images
│   ├── styles.css        # Main stylesheet
│   ├── favicon.ico       # Website favicon
│
├── templates/            # HTML templates (Jinja2)
│   ├── homepage.html     # Base layout
│   ├── index.html        # Homepage template
│   ├── cart.html         # Shopping cart page
│   ├── checkout.html     # Checkout page
│   ├── confirmation.html # Order confirmation page
│   ├── jewelry.html      # Jewelry page
│   ├── tops.html         # Tops page
│   ├── bottoms.html      # Bottoms page
│   ├── shoes.html        # Shoes page
├── app.py                # Main Flask application
├── cart.db               # SQLITE database for cart
├── DESIGN.md             # Project design document
└── README.md             # Project documentation

I put all of the static files, such as images and my css file, into the static folder. The CSS is the style for most of the pages of my project, but for some pages, the CSS is included in style tags on its individual html file instead. To explain the names of the image files, the name of each image file is (item_price).png.. I did this because in my "add to cart" function which is at the end of each html file (jewelry, tops, bottoms, and shoes .html), fetches the add to cart route which is in app.py. This route refers to the image file as **file_name = f"{price}.png"** when adding it to the cart table. therefore the name of each image has to be the price, then dot png after. The static folder also holds the favicon image that is displayed on the tab when a user is on the website. Next, in my templates folder, is every html file in my project. Each of the files are named in accordance of the page that they represent. The html of the four main pages include a gallery of images with text under it that describe the item and its price. There is also an "add to cart" button below each item. The homepage html page is simply the homepage html, and the index is the header that is visible on each item page which has links that bring users to the pages of the website. Cart.html is the html for the cart page, which includes a list of the items in the database cart.db, including delete buttons so the user can delete items from the database, a calculate total button, and a checkout button. Checkout.html is the html for the checkout page, which is a form incuding the user's card and address information. Lastly, the confirmation.html file includes the html for the confirmation page, which is simply a check image and a thank you message for shopping at the boutique. Next are the files that are not within a sub-folder. App.py is the flask routes for the website, which I will go into depth into later. Cart.db is the database for the items that the user puts into the cart. DESIGN.md and README.md are md documents about my project.


2. Database design
**Schema of cart.db**

CREATE TABLE cart (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subpage TEXT NOT NULL,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    image_url TEXT NOT NULL
);

The schema of my cart database include the id of the item, which automatically increments when a user adds an item, the name of the subpage that the item is from (shoes, tops, bottoms, jewelry), the name of the item, the price of the item, and the imgage url of the item. I constructed my database like this because all of this information is needed to know to be shown on the cart page, so the information should be recorded for each item when a user adds it into the cart. Yet, I feel that the "id" category was unnecesary because this data is not used anywhere in my project.


**More about Frontend Design**
For my CSS/HTML, I used a base template called homepage.html, which has a reuseable header, footer, and navigation sections. Pages such as (shoes, tops, bottoms, jewelry).html extend homepage.html. This made my program easier to style.
For my usage of Javascript, I used javascript functions when I wanted to make dynamic updates to my webpage. My function addToCart uses Javascript's fetch API. The adds the information of the item clicked to the cart.db database, and it is triggered by the click of the "add to cart" button. <button onclick="addToCart('Jewelry', 'Rose Necklace', 34.00, '34.png')">Add to Cart</button>
This is a line of text from my html for the jewelery subpage. The arguments are input into the cart.db database, and the function inputs a new column into both the databse and the visual cart on the cart subpage as well. Again, I named all of the image files as the image price .png because this was the identifier I used to tell the program which image they should add to the database.
In addition, I added a discount script in my jewelery.html page. The discount script applies a discount to the jewelery items and changes the color of the price text. It also makes it so that the new price of the item is added to the cart/cart database instead of the old price when the user presses the "add to cart" button.
For the cart.html, I used a calculateTotal function as well, which will add the sum of all of the prices in the cart table and add them, then display it. There is also the checkout button, which brings the user to the next page. 

**More about Backend Design**
Each route in app.py corresponds to a different user action. (e.g., viewing a category, managing the cart). This is a description of all of the routes: (below)
Certain routes (e.g., /add_to_cart) are designed to behave like APIs, processing JSON requests and returning JSON responses.

**route description**
/ (Homepage Route)
HTTP Method: GET
Purpose: Displays the homepage (index.html). This is the main entry point to your application.

/<category> (Category Route)
HTTP Method: GET
Purpose: Dynamically renders a page for a specific category of items. For example:
/tops renders tops.html.
/shoes renders shoes.html.

/cart (Cart Route)
HTTP Method: GET
Purpose: Displays the current shopping cart contents. Retrieves all items from the database and passes them to cart.html.

/add_to_cart (Add to Cart Route)
HTTP Method: POST
Purpose: Adds an item to the cart. Expects a JSON payload with details of the item (subpage, name, price, image_url). Validates image existence and stores the item in the database.

/delete_item/<int:item_id> (Delete Item Route)
HTTP Method: POST
Purpose: Removes an item from the cart based on its unique item_id. After deletion, redirects back to the cart page.

/calculate_total (Calculate Total Route)
HTTP Method: GET
Purpose: Calculates the total price of all items in the cart by summing the price column in the database. Returns the total as a JSON response.

/checkout (Checkout Route)
HTTP Method: GET
Purpose: Displays the checkout page, including the total price of all items in the cart. Retrieves the total price from the database.

/submit_checkout (Submit Checkout Route)
HTTP Method: POST
Purpose: Processes the checkout form submission. Deletes all items from the cart to simulate order completion and redirects to a confirmation page with the user's name.




- **Flask**: Web framework used to build the backend.
- **HTML/CSS**: Used for designing the front end.
- **JavaScript**: For handling dynamic interactions on the page.
- **SQLite**: For storing user and order data.
- **Bootstrap**: For styling and responsive design.




