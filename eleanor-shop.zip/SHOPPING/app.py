from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
import sqlite3
import os


app = Flask(__name__)

# Initialize SQLite Cart database


def init_db():
    conn = sqlite3.connect('cart.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS cart (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    subpage TEXT,
                    name TEXT,
                    price REAL,
                    image_url TEXT
                )''')
    conn.commit()
    conn.close()


@app.route('/')
def index():
    # Render and return the 'index.html' template when the home page (/) is accessed
    return render_template('index.html')


@app.route('/<category>')
def category_page(category):
    # Render and return the template based on the category passed in the URL
    # For example, if the URL is /tops, it will render 'tops.html'
    return render_template(f'{category}.html')


@app.route('/cart')
def cart():
    conn = sqlite3.connect('cart.db')
    c = conn.cursor()
    c.execute("SELECT id, subpage, name, price, image_url FROM cart")
    items = c.fetchall()
    conn.close()
    # Log the items fetched from the database
    app.logger.info(f"Items fetched: {items}")
    # Convert database rows into dictionaries for easier template rendering
    items = [{'id': row[0], 'subpage': row[1], 'name': row[2],
              'price': row[3], 'image_url': row[4]} for row in items]
    app.logger.info(f"Items converted to dictionaries: {items}")
    return render_template('cart.html', items=items)


@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    data = request.json
    app.logger.info(f"Received data: {data}")

    # Extract data from the request
    subpage = data['subpage']
    name = data['name']
    price = data['price']  # Assume price is numeric or convertible to a string

    # Construct the image file name based on the price
    file_name = f"{price}.png"
    image_path = os.path.join('static', 'images', file_name)

    # Validate if the image file exists
    if not os.path.exists(image_path):
        app.logger.error(f"Image file not found: {image_path}")
        return jsonify({"error": f"Image for price {price} not found"}), 404

    # Store the item in the database
    conn = sqlite3.connect('cart.db')
    c = conn.cursor()

    try:
        # Insert into the database
        c.execute(
            "INSERT INTO cart (subpage, name, price, image_url) VALUES (?, ?, ?, ?)",
            (subpage, name, price, file_name)  # Store the file_name instead of the full URL
        )
        conn.commit()
        app.logger.info(f"Item successfully added to database: {name}, {price}, {file_name}")
    except sqlite3.Error as e:
        app.logger.error(f"Database error: {e}")
        return jsonify({"error": "Failed to add item to the database"}), 500
    finally:
        conn.close()

    # Prepare response data
    cart_item = {
        "subpage": subpage,
        "name": name,
        "price": price,
        "image": file_name  # Return the file name
    }
    return jsonify({"message": "Item added to cart", "cart_item": cart_item})


@app.route('/delete_item/<int:item_id>', methods=['POST'])
def delete_item(item_id):
    app.logger.info(f"Deleting item with id: {item_id}")
    # Connect to the database
    conn = sqlite3.connect('cart.db')
    c = conn.cursor()

    # Delete the item from the cart table based on item_id
    c.execute("DELETE FROM cart WHERE id = ?", (item_id,))
    conn.commit()

    # Close the connection
    conn.close()

    # Redirect back to the cart page to refresh the list of items
    return redirect(url_for('cart'))

# Route to calculate the total price of cart


@app.route('/calculate_total', methods=['GET'])
# Takes a sum of all numbers in the price column of the cart table
def calculate_total():
    conn = sqlite3.connect('cart.db')
    c = conn.cursor()
    c.execute("SELECT SUM(price) FROM cart")
    total = c.fetchone()[0] or 0
    conn.close()
# Returns the total integer
    return jsonify({"total": total})


@app.route('/checkout', methods=['GET'])
def checkout():
    # Get the cart total from the database
    conn = sqlite3.connect('cart.db')
    c = conn.cursor()
    c.execute("SELECT SUM(price) FROM cart")
    total = c.fetchone()[0] or 0
    conn.close()

    # Render the checkout page and pass the total
    return render_template('checkout.html', total=total)


@app.route('/submit_checkout', methods=['POST'])
def submit_checkout():
    card_name = request.form['card_name']

    # Connect to the database
    conn = sqlite3.connect('cart.db')
    c = conn.cursor()

    try:
        # Delete all items from the cart
        c.execute("DELETE FROM cart")
        conn.commit()

        # Redirect to the confirmation page, passing the cardholder's name
        return render_template('confirmation.html', name=card_name)

    except sqlite3.Error as e:
        # Handle any database errors (e.g., unable to delete)
        app.logger.error(f"Database error: {e}")
        return "An error occurred, please try again later.", 500
    finally:
        conn.close()


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
